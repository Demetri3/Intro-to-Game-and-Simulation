﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// New Using statements
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {
    //This is where our game logic will be run
    // Use this for initialization
    [Header("Wave Settings")]
    public GameObject hazard; //what are we spawning
    public Vector2 spawn; // where do we spawn our hazards
    public int hazardCount; // How many hazards per wave?
    public float startWait; //How long until the first wave?
    public float spawnWait; // How long between each hazard in each wave?
    public float waveWait;  // How long between each wave?
    public Text ScoreText;  //Score
    public Text gameOverText;  //Game Over text
    public Text restartText; 
    private int score;  // Game score
    private bool gameOver; // Game over
    private bool restart; // Restart or not
 
	void Start () {
      
        score = 0;
        StartCoroutine(SpawnWaves());
        gameOver = false;
        restart = false;
        UpdateScore();
	}
    // Function dedicated to spawning waves of hazards
    // Continue

    void Update()
    {
        //Check weather you are restarting
        if (restart)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                //Resatrt our game
                //Aplication.LoadLevel1("Level")
                //New way Use this!
                // SceneManager.LoadScene("SampleScene");
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);


            }



        }
    }
    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(startWait); // This will wait for start wait seconds
        while(true) 
        {
            // Spawning out hazards

            for (int i = 0; i < hazardCount; i++)
            {
                Vector2 spawnPosition = new Vector2(spawn.x, Random.Range(-spawn.y, spawn.y));
                //                                     11                   -4          4
                Instantiate(hazard, spawnPosition, Quaternion.identity);
                yield return new WaitForSeconds(spawnWait);
            }
            yield return new WaitForSeconds(waveWait);
            //Restart Logic
            if (gameOver)
            {
                //Avtivate Restart UI Text
                restart.Text.enable= true;

                //(Optional) restart UI Text
                //Set restart boolean value true





            }

        }
        

    }

    public void AddScore(int newScorValue)
    {
        score += newScorValue; // Score= score + newScoreValue
        // Debug.Log("Score" + score);
        UpdateScore();
    }

    void UpdateScore()
    {
        ScoreText.text = "Score:" + score;
    }

    public void GameOver()
    {
        //What Happens when my game is over
        gameOver = true;
        gameOverText.enabled = true;
    }



}
